package com.example.clms;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class LT_Home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lt_home);
    }

    public void add(View view) {
        Intent i = new Intent(LT_Home.this, Add_Book.class);
        i.putExtra("person", "LT");
        startActivity(i);
    }

    public void search(View view) {
        Intent i = new Intent(LT_Home.this, Search.class);
        i.putExtra("person", "LT");
        startActivity(i);
    }

    public void Return(View view) {
        Intent i = new Intent(LT_Home.this, Return_Book.class);
        i.putExtra("person", "LT");
        startActivity(i);
    }
}