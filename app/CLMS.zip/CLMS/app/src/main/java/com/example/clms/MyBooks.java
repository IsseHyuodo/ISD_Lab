package com.example.clms;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MyBooks extends AppCompatActivity {

    RecyclerView.Adapter adapter;

    FirebaseDatabase rootNode;
    DatabaseReference ref;
    private List<MyBook> myBooks=new ArrayList<>();
    RecyclerView recyclerView;

    public void onBackPressed() {
        finish();
        super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_books);
        recyclerView = (RecyclerView) findViewById(R.id.recycler);
        showBook();
        recyclerView.setLayoutManager(new LinearLayoutManager(getParent()));
        adapter=new Adapter(myBooks);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);
    }

    private void showBook() {

        MyBook book = new MyBook(5,"23-6789-4","ABC", "ECE", "Henry", "XYZ", 345, "A/45");
        myBooks.add(book);
        myBooks.add(book);
        myBooks.add(book);
        myBooks.add(book);
        myBooks.add(book);
        myBooks.add(book);
        myBooks.add(book);
        myBooks.add(book);
        myBooks.add(book);
        myBooks.add(book);

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater()
                .inflate(R.menu.my_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //Toast.makeText(this, "Selected Item: " + item.getTitle(), Toast.LENGTH_SHORT)
                //.show();
        Intent i;
        switch (item.getItemId()) {
            case R.id.my_books:
                return true;
            case R.id.search_books:
                i = new Intent(MyBooks.this, Search.class);
                i.putExtra("person", "User");
                startActivity(i);
                return true;
            case R.id.me:
                i = new Intent(MyBooks.this, UserHome.class);
                i.putExtra("person", "User");
                startActivity(i);
                return true;
            case R.id.Log_Out:
                i = new Intent(MyBooks.this, SignIn.class);
                i.putExtra("Type", "Student/Faculty");
                i.putExtra("person", "User");
                startActivity(i);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}