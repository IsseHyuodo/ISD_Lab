package com.example.clms;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignIn extends AppCompatActivity {
    private FirebaseAuth auth;
    private EditText userid;
    private EditText password;
    private TextView head;
    private Button signin;
    String type;

    FirebaseDatabase rootNode;
    DatabaseReference ref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        head = (TextView) findViewById(R.id.textView);
        userid = (EditText) findViewById(R.id.userid);
        password = (EditText) findViewById(R.id.password_login);
        signin = (Button) findViewById(R.id.signin);
        auth = FirebaseAuth.getInstance();

        Intent i = getIntent();
        type = i.getStringExtra("Type");

        head.setText(type + " Log In");

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String useriddata =userid.getText().toString();
                String passworddata = password.getText().toString();

                if(TextUtils.isEmpty(useriddata) || TextUtils.isEmpty(passworddata)){
                    Toast.makeText(SignIn.this, "Enter all the details.", Toast.LENGTH_SHORT).show();
                }else{
                    login(useriddata , passworddata);

                }
            }
        });
    }

    private void login(String useriddata , String passworddata){
        /*auth.signInWithEmailAndPassword(useriddata , passworddata).addOnSuccessListener(SignIn.this, new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                Toast.makeText(SignIn.this, "Signed In Successfully", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(SignIn.this , UserHome.class);

            }
        });*/
        Toast.makeText(SignIn.this, "Signed In Successfully", Toast.LENGTH_SHORT).show();
        Intent intent;
        if(type.equalsIgnoreCase("Student/Faculty"))
        {
            intent = new Intent(SignIn.this , UserHome.class);
            startActivity(intent);
        }
        else if(type.equalsIgnoreCase("Assistant Librarian"))
        {
            intent = new Intent(SignIn.this , LT_Home.class);
            startActivity(intent);
        }
        else if(type.equalsIgnoreCase("Library Trainee"))
        {
            intent = new Intent(SignIn.this , LT_Home.class);
            startActivity(intent);
        }


    }



}