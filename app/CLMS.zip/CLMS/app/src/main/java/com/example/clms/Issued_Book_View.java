package com.example.clms;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Issued_Book_View extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_issued_book_view);
    }
}